#include <stdio.h>
#include "hello.h"

int hello(){
	printf("Hello, Embeded system!!\n");
	return 0;
}
